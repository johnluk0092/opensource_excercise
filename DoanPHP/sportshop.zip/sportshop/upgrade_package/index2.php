<?php
// Include the header
require('include/header.php');
require('include/sidebar.php');
?>


<body>
	<h1>WELLCOME</h1>

</body>
<?php
// Include the footer
require('include/footer.php');

// Include the scripts
require('include/script.php');
?>
