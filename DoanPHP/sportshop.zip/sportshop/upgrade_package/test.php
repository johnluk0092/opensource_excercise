<?php
$conn = new mysqli("localhost", "root", "", "ecommerce"); // Make sure 'ecommerce' is your correct database name

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Replace 'products' with your actual table name
$sql = "SELECT images FROM products WHERE id = 1"; 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $image_filename = $row['images']; // Example: "67e56a874048e.png"
    
    $image_path = "img/" . $image_filename; // Ensure this matches your actual image folder path
    
    if (file_exists($image_path)) {
        echo '<img src="' . $image_path . '" alt="Product Image">';
    } else {
        echo "Image file not found: " . $image_path;
    }
} else {
    echo "No image found in the database.";
}

$conn->close();
?> 
