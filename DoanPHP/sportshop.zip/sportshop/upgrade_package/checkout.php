<?php
require('include/header.php');
require('include/sidebar.php');
require('../db/conn1.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get user's pending order
$stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? AND status = 'Pending'");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();

if (!$order) {
    header("Location: cart.php");
    exit();
}

$order_id = $order['id'];

// Get order items
$stmt = $conn->prepare("SELECT od.*, p.name, p.images 
                       FROM order_details od 
                       JOIN products p ON od.product_id = p.id 
                       WHERE od.order_id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$items = $stmt->get_result();

// Calculate total
$total = 0;
while ($item = $items->fetch_assoc()) {
    $total += $item['price'] * $item['qty'];
}
?>

<!-- Checkout Section Begin -->
<section class="checkout spad">
    <div class="container">
        <div class="checkout__form">
            <h4>Payment Details</h4>
            <form action="process-payment.php" method="POST">
                <div class="row">
                    <div class="col-lg-8 col-md-6">
                        <div class="checkout__input">
                            <p>Full Name<span>*</span></p>
                            <input type="text" name="fullname" required>
                        </div>
                        <div class="checkout__input">
                            <p>Address<span>*</span></p>
                            <input type="text" name="address" required>
                        </div>
                        <div class="checkout__input">
                            <p>Phone<span>*</span></p>
                            <input type="text" name="phone" required>
                        </div>
                        <div class="checkout__input">
                            <p>Email<span>*</span></p>
                            <input type="email" name="email" required>
                        </div>
                        
                        <div class="checkout__input">
                            <p>Card Number<span>*</span></p>
                            <input type="text" name="card_number" placeholder="4242 4242 4242 4242" required>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="checkout__input">
                                    <p>Expiration Date<span>*</span></p>
                                    <input type="text" name="exp_date" placeholder="MM/YY" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="checkout__input">
                                    <p>CVV<span>*</span></p>
                                    <input type="text" name="cvv" placeholder="123" required>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="checkout__order">
                            <h4>Your Order</h4>
                            <div class="checkout__order__products">Products <span>Total</span></div>
                            <ul>
                                <?php 
                                $items->data_seek(0); // Reset pointer
                                while ($item = $items->fetch_assoc()): 
                                    $subtotal = $item['price'] * $item['qty'];
                                ?>
                                    <li><?= htmlspecialchars($item['name']) ?> x <?= $item['qty'] ?> <span><?= number_format($subtotal, 0, ',', '.') ?>₫</span></li>
                                <?php endwhile; ?>
                            </ul>
                            <div class="checkout__order__subtotal">Subtotal <span><?= number_format($total, 0, ',', '.') ?>₫</span></div>
                            <div class="checkout__order__total">Total <span><?= number_format($total, 0, ',', '.') ?>₫</span></div>
                            
                            <button type="submit" class="site-btn">PLACE ORDER</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>
<!-- Checkout Section End -->

<?php
require('include/footer.php');
require('include/script.php');
?>