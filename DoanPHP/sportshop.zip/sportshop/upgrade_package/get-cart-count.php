<?php
require('../db/conn1.php');
session_start();

$count = 0;

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $stmt = $conn->prepare("SELECT SUM(od.qty) as total 
                           FROM order_details od 
                           JOIN orders o ON od.order_id = o.id 
                           WHERE o.user_id = ? AND o.status = 'Pending'");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $count = $row['total'] ?? 0;
}

echo $count;
?>