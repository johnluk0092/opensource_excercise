<?php
/* 
 * Complete Purchase System in One File
 * Handles both product display and checkout
 */

session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ==================== DATABASE CONNECTION ====================
$conn = new mysqli('localhost', 'root', '', 'ecommerce');
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$conn->set_charset("utf8mb4");

// ==================== CHECKOUT PROCESSING ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    if (!isset($_SESSION['user_id'])) {
        die(json_encode(['success' => false, 'error' => 'Not logged in']));
    }
    
    // Process dummy payment and create order
    try {
        $conn->begin_transaction();
        
        // 1. Create order
        $stmt = $conn->prepare("INSERT INTO orders 
            (user_id, status, firstname, lastname, address, phone, email, payment_method) 
            VALUES (?, 'Processing', ?, ?, ?, ?, ?, 'Credit Card')");
        $stmt->bind_param("isssss", 
            $_SESSION['user_id'],
            $_POST['firstname'],
            $_POST['lastname'],
            $_POST['address'],
            $_POST['phone'],
            $_POST['email']
        );
        $stmt->execute();
        $order_id = $conn->insert_id;
        
        // 2. Add all cart items to order_details
        $stmt = $conn->prepare("INSERT INTO order_details 
            (order_id, product_id, qty, price, total) 
            SELECT ?, p.id, 1, p.price, p.price 
            FROM products p 
            WHERE p.id IN (" . implode(',', array_fill(0, count($_POST['product_ids']), '?')) . ")");
        
        $types = str_repeat('i', count($_POST['product_ids']));
        $stmt->bind_param("i$types", $order_id, ...$_POST['product_ids']);
        $stmt->execute();
        
        $conn->commit();
        
        // Redirect to thank you page
        header("Location: purchase.php?order_id=$order_id");
        exit;
        
    } catch (Exception $e) {
        $conn->rollback();
        die("Order failed: " . $e->getMessage());
    }
}

// ==================== HTML OUTPUT ====================
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Commerce Purchase</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; }
        .product-card { background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .product-image { height: 200px; background-size: cover; background-position: center; }
        .product-info { padding: 15px; }
        .checkout-form { background: white; padding: 20px; border-radius: 8px; margin-top: 30px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; }
        button { background: #4CAF50; color: white; border: none; padding: 10px 15px; border-radius: 4px; cursor: pointer; }
        .hidden { display: none; }
        .thank-you { text-align: center; padding: 50px 0; }
    </style>
</head>
<body>
    <div class="container">
        <?php if (isset($_GET['order_id'])): ?>
            <!-- Thank You Page -->
            <div class="thank-you">
                <h1><i class="fas fa-check-circle" style="color:green;font-size:50px;"></i></h1>
                <h2>Thank You For Your Purchase!</h2>
                <p>Your order #<?= htmlspecialchars($_GET['order_id']) ?> has been received.</p>
                <a href="purchase.php" class="button">Continue Shopping</a>
            </div>
        
        <?php else: ?>
            <!-- Product Listing -->
            <h1>Our Products</h1>
            <div class="product-grid">
                <?php
                $result = $conn->query("SELECT * FROM products WHERE status='Active' LIMIT 6");
                while ($product = $result->fetch_assoc()):
                ?>
                <div class="product-card" data-id="<?= $product['id'] ?>">
                    <div class="product-image" style="background-image:url('img/<?= htmlspecialchars($product['images']) ?>')"></div>
                    <div class="product-info">
                        <h3><?= htmlspecialchars($product['name']) ?></h3>
                        <p><?= number_format($product['price'], 0, ',', '.') ?>₫</p>
                        <button class="add-to-cart"><i class="fas fa-shopping-cart"></i> Add to Cart</button>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
            
            <!-- Checkout Form (Initially Hidden) -->
            <div id="checkout-section" class="checkout-form hidden">
                <h2>Checkout</h2>
                <form id="checkout-form" method="POST">
                    <input type="hidden" name="checkout" value="1">
                    <input type="hidden" name="product_ids" id="product-ids" value="">
                    
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" name="firstname" required value="John">
                    </div>
                    
                    <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" name="lastname" required value="Doe">
                    </div>
                    
                    <div class="form-group">
                        <label>Address</label>
                        <input type="text" name="address" required value="123 Main St">
                    </div>
                    
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" name="phone" required value="0123456789">
                    </div>
                    
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" required value="test@example.com">
                    </div>
                    
                    <div class="form-group">
                        <label>Card Number</label>
                        <input type="text" value="4242 4242 4242 4242" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>Expiry Date</label>
                        <input type="text" value="12/25" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>CVV</label>
                        <input type="text" value="123" readonly>
                    </div>
                    
                    <button type="submit">Complete Purchase</button>
                </form>
            </div>
            
            <!-- Cart Floating Button -->
            <div style="position:fixed; bottom:20px; right:20px;">
                <button id="cart-button" style="border-radius:50%; width:60px; height:60px; font-size:20px;">
                    <i class="fas fa-shopping-cart"></i>
                    <span id="cart-count">0</span>
                </button>
            </div>
            
            <script>
            const cart = [];
            
            // Add to cart functionality
            document.querySelectorAll('.add-to-cart').forEach(button => {
                button.addEventListener('click', () => {
                    const productId = button.closest('.product-card').dataset.id;
                    if (!cart.includes(productId)) {
                        cart.push(productId);
                        updateCartUI();
                    }
                });
            });
            
            // Cart button click shows checkout
            document.getElementById('cart-button').addEventListener('click', () => {
                if (cart.length > 0) {
                    document.getElementById('checkout-section').classList.remove('hidden');
                    document.getElementById('product-ids').value = cart.join(',');
                    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
                }
            });
            
            function updateCartUI() {
                document.getElementById('cart-count').textContent = cart.length;
            }
            </script>
        <?php endif; ?>
    </div>
</body>
</html>