<?php
require('include/header.php');
require('include/sidebar.php');
require('../db/conn1.php');
session_start();

if (!isset($_SESSION['user_id']) || !isset($_GET['order_id'])) {
    header("Location: index.php");
    exit();
}

$order_id = intval($_GET['order_id']);
$user_id = $_SESSION['user_id'];

// Verify order belongs to user
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $order_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();

if (!$order) {
    header("Location: index.php");
    exit();
}
?>

<!-- Thank You Section Begin -->
<section class="thank-you spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="thank-you__text">
                    <span>Thank You!</span>
                    <h2>Your Order #<?= $order_id ?> Has Been Received</h2>
                    <p>We've sent a confirmation email to <?= htmlspecialchars($order['email']) ?></p>
                    <a href="index.php" class="primary-btn">Continue Shopping</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Thank You Section End -->

<?php
require('include/footer.php');
require('include/script.php');
?>