<?php
require('../db/conn.php');

$id = $_GET['id'] ?? 0;

if ($id) {
    $stmt = $conn->prepare("UPDATE categories SET status = 'Inactive' WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

header("Location: addcategory.php");
exit();
?>