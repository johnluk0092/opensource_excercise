<?php
require('includes/header.php');
require('../db/conn.php');

// Initialize variables
$name = $slug = '';
$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Process order data
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $status = $_POST['status'];
    
    // Insert into orders table
    $stmt = $conn->prepare("INSERT INTO orders (firstname, lastname, email, phone, address, status, created_at) 
                           VALUES (?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssssss", $firstname, $lastname, $email, $phone, $address, $status);
    $stmt->execute();
    $order_id = $conn->insert_id;
    
    // Process order details
    $product_ids = $_POST['product_id'];
    $prices = $_POST['price'];
    $quantities = $_POST['quantity'];
    
    for ($i = 0; $i < count($product_ids); $i++) {
        $total = $prices[$i] * $quantities[$i];
        $stmt = $conn->prepare("INSERT INTO order_details (order_id, product_id, price, qty, total) 
                              VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iidid", $order_id, $product_ids[$i], $prices[$i], $quantities[$i], $total);
        $stmt->execute();
    }
    
    $success = "Order #$order_id added successfully!";
}

// Handle order deletion
if (isset($_GET['delete'])) {
    $order_id = $_GET['delete'];
    $conn->query("DELETE FROM order_details WHERE order_id = $order_id");
    $conn->query("DELETE FROM orders WHERE id = $order_id");
    $success = "Order #$order_id deleted successfully!";
}

// Fetch all orders for display with product count
$orders = $conn->query("
    SELECT o.*, COUNT(od.id) as product_count 
    FROM orders o
    LEFT JOIN order_details od ON o.id = od.order_id
    GROUP BY o.id
    ORDER BY o.created_at DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.0/font/bootstrap-icons.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <h2 class="mb-4">Add New Order</h2>
                
                <?php if (isset($success)): ?>
                    <div class="alert alert-success"><?= $success ?></div>
                <?php endif; ?>
                
                <form method="POST" class="mb-5">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">First Name</label>
                                <input type="text" class="form-control" name="firstname" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Last Name</label>
                                <input type="text" class="form-control" name="lastname" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" name="email" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Phone</label>
                                <input type="text" class="form-control" name="phone" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Address</label>
                        <textarea class="form-control" name="address" required></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select class="form-select" name="status">
                            <option value="Processing">Processing</option>
                            <option value="Confirmed">Confirmed</option>
                            <option value="Shipping">Shipping</option>
                            <option value="Delivered">Delivered</option>
                        </select>
                    </div>
                    
                    <h4 class="mb-3">Products</h4>
                    <div id="product-container">
                        <div class="row product-row mb-2">
                            <div class="col-md-5">
                                <select class="form-select product-select" name="product_id[]" required>
                                    <option value="">Select Product</option>
                                    <?php 
                                    $products = $conn->query("SELECT id, name, price FROM products");
                                    while ($product = $products->fetch_assoc()): ?>
                                        <option value="<?= $product['id'] ?>" data-price="<?= $product['price'] ?>">
                                            <?= htmlspecialchars($product['name']) ?> - $<?= number_format($product['price'], 2) ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <input type="number" class="form-control" name="price[]" step="0.01" min="0" required>
                            </div>
                            <div class="col-md-2">
                                <input type="number" class="form-control" name="quantity[]" min="1" value="1" required>
                            </div>
                            <div class="col-md-2">
                                <span class="form-control total-price">$0.00</span>
                            </div>
                            <div class="col-md-1">
                                <button type="button" class="btn btn-danger remove-product"><i class="bi bi-x"></i></button>
                            </div>
                        </div>
                    </div>
                    
                    <button type="button" id="add-product" class="btn btn-secondary mb-4">
                        <i class="bi bi-plus"></i> Add Product
                    </button>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Save Order</button>
                    </div>
                </form>
                
                <h2 class="mb-4">Order List</h2>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Products</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($order = $orders->fetch_assoc()): ?>
                            <tr>
                                <td><?= $order['id'] ?></td>
                                <td><?= htmlspecialchars($order['firstname'] . ' ' . $order['lastname']) ?></td>
                                <td><?= htmlspecialchars($order['email']) ?></td>
                                <td><?= htmlspecialchars($order['phone']) ?></td>
                                <td><?= $order['product_count'] ?></td>
                                <td>
                                    <span class="badge bg-<?= 
                                        $order['status'] == 'Processing' ? 'warning' : 
                                        ($order['status'] == 'Confirmed' ? 'info' : 
                                        ($order['status'] == 'Shipping' ? 'primary' : 
                                        ($order['status'] == 'Delivered' ? 'success' : 'secondary')))
                                        ?>">
                                        <?= $order['status'] ?>
                                    </span>
                                </td>
                                <td><?= date('M d, Y h:i A', strtotime($order['created_at'])) ?></td>
                                <td>
                                    <a href="editorder.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-warning">
                                        <i class="bi bi-pencil"></i> Edit
                                    </a>
                                    <a href="?delete=<?= $order['id'] ?>" class="btn btn-sm btn-danger" 
                                       onclick="return confirm('Are you sure you want to delete this order?')">
                                        <i class="bi bi-trash"></i> Delete
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Add new product row
        document.getElementById('add-product').addEventListener('click', function() {
            const container = document.getElementById('product-container');
            const newRow = container.querySelector('.product-row').cloneNode(true);
            
            // Clear values
            newRow.querySelector('.product-select').selectedIndex = 0;
            newRow.querySelector('[name="price[]"]').value = '';
            newRow.querySelector('[name="quantity[]"]').value = '1';
            newRow.querySelector('.total-price').textContent = '$0.00';
            
            container.appendChild(newRow);
        });
        
        // Remove product row
        document.getElementById('product-container').addEventListener('click', function(e) {
            if (e.target.classList.contains('remove-product') || 
                e.target.closest('.remove-product')) {
                const rows = document.querySelectorAll('.product-row');
                if (rows.length > 1) {
                    const row = e.target.closest('.product-row');
                    row.remove();
                } else {
                    // Clear values but keep the row if it's the last one
                    const row = e.target.closest('.product-row');
                    row.querySelector('.product-select').selectedIndex = 0;
                    row.querySelector('[name="price[]"]').value = '';
                    row.querySelector('[name="quantity[]"]').value = '1';
                    row.querySelector('.total-price').textContent = '$0.00';
                }
            }
        });
        
        // Update price when product is selected
        document.getElementById('product-container').addEventListener('change', function(e) {
            if (e.target.classList.contains('product-select')) {
                const row = e.target.closest('.product-row');
                const selectedOption = e.target.options[e.target.selectedIndex];
                const priceInput = row.querySelector('[name="price[]"]');
                
                if (selectedOption.value) {
                    priceInput.value = selectedOption.dataset.price;
                    calculateTotal(row);
                }
            }
        });
        
        // Calculate total when price or quantity changes
        document.getElementById('product-container').addEventListener('input', function(e) {
            if (e.target.name === 'price[]' || e.target.name === 'quantity[]') {
                calculateTotal(e.target.closest('.product-row'));
            }
        });
        
        function calculateTotal(row) {
            const price = parseFloat(row.querySelector('[name="price[]"]').value) || 0;
            const qty = parseInt(row.querySelector('[name="quantity[]"]').value) || 0;
            const total = price * qty;
            row.querySelector('.total-price').textContent = '$' + total.toFixed(2);
        }
    });
    </script>
</body>
</html>
<?php
require_once('includes/footer.php');
?>