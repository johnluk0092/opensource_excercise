<?php
require('includes/header.php');
require('../db/conn.php');

$id = $_GET['id'] ?? 0;
$error = '';
$success = '';

// Fetch order data with details
$order_query = $conn->prepare("
    SELECT o.* 
    FROM orders o
    WHERE o.id = ?
");
$order_query->bind_param("i", $id);
$order_query->execute();
$order = $order_query->get_result()->fetch_assoc();

if (!$order) {
    header("Location: orders.php");
    exit();
}

// Fetch order details with product names
$details_query = $conn->prepare("
    SELECT od.*, p.name as product_name 
    FROM order_details od
    JOIN products p ON od.product_id = p.id
    WHERE od.order_id = ?
");
$details_query->bind_param("i", $id);
$details_query->execute();
$order['products'] = $details_query->get_result()->fetch_all(MYSQLI_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $order = [
        'id' => $id,
        'firstname' => trim($_POST['firstname']),
        'lastname' => trim($_POST['lastname']),
        'email' => trim($_POST['email']),
        'phone' => trim($_POST['phone']),
        'address' => trim($_POST['address']),
        'status' => trim($_POST['status']),
        'products' => []
    ];
    
    // Process product data
    if (isset($_POST['product_id'])) {
        foreach ($_POST['product_id'] as $index => $product_id) {
            if (!empty($product_id)) {
                $order['products'][] = [
                    'product_id' => $product_id,
                    'price' => $_POST['product_price'][$index],
                    'qty' => $_POST['product_qty'][$index],
                    'product_name' => $_POST['product_name'][$index]
                ];
            }
        }
    }
    
    // Validate inputs
    if (empty($order['firstname']) || empty($order['lastname']) || 
        empty($order['email']) || empty($order['phone']) || empty($order['address'])) {
        $error = 'All customer fields are required';
    } elseif (empty($order['products'])) {
        $error = 'At least one product is required';
    } else {
        $conn->begin_transaction();
        try {
            // Update order
            $stmt = $conn->prepare("UPDATE orders SET 
                firstname = ?, lastname = ?, email = ?, phone = ?, 
                address = ?, status = ?, updated_at = NOW()
                WHERE id = ?");
            $stmt->bind_param("ssssssi", 
                $order['firstname'], $order['lastname'], $order['email'],
                $order['phone'], $order['address'], $order['status'], $order['id']);
            
            if (!$stmt->execute()) {
                throw new Exception('Error updating order: ' . $conn->error);
            }
            
            // Delete existing order details
            $conn->query("DELETE FROM order_details WHERE order_id = $id");
            
            // Insert new order details
            foreach ($order['products'] as $product) {
                $total = $product['price'] * $product['qty'];
                $stmt = $conn->prepare("INSERT INTO order_details 
                    (order_id, product_id, price, qty, total) 
                    VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("iidid", 
                    $id, $product['product_id'], $product['price'], $product['qty'], $total);
                
                if (!$stmt->execute()) {
                    throw new Exception('Error saving order details: ' . $conn->error);
                }
            }
            
            $conn->commit();
            $success = 'Order updated successfully!';
            
            // Refresh order details
            $details_query->execute();
            $order['products'] = $details_query->get_result()->fetch_all(MYSQLI_ASSOC);
            
        } catch (Exception $e) {
            $conn->rollback();
            $error = $e->getMessage();
        }
    }
}

// Fetch all active products for dropdown
$products = $conn->query("SELECT id, name, price FROM products WHERE status = 'Active'")->fetch_all(MYSQLI_ASSOC);
?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <h2 class="mb-4">Edit Order #<?= $id ?></h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" class="form-control" name="firstname" 
                                   value="<?= htmlspecialchars($order['firstname']) ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" class="form-control" name="lastname" 
                                   value="<?= htmlspecialchars($order['lastname']) ?>" required>
                        </div>
                    </div>
                </div>
                
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control" name="email" 
                                   value="<?= htmlspecialchars($order['email']) ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Phone</label>
                            <input type="text" class="form-control" name="phone" 
                                   value="<?= htmlspecialchars($order['phone']) ?>" required>
                        </div>
                    </div>
                </div>
                
                <div class="form-group mb-4">
                    <label>Address</label>
                    <textarea class="form-control" name="address" required><?= htmlspecialchars($order['address']) ?></textarea>
                </div>
                
                <div class="form-group mb-4">
                    <label>Status</label>
                    <select class="form-control" name="status">
                        <option value="Processing" <?= $order['status'] == 'Processing' ? 'selected' : '' ?>>Processing</option>
                        <option value="Confirmed" <?= $order['status'] == 'Confirmed' ? 'selected' : '' ?>>Confirmed</option>
                        <option value="Shipping" <?= $order['status'] == 'Shipping' ? 'selected' : '' ?>>Shipping</option>
                        <option value="Delivered" <?= $order['status'] == 'Delivered' ? 'selected' : '' ?>>Delivered</option>
                        <option value="Cancelled" <?= $order['status'] == 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    </select>
                </div>
                
                <h4 class="mb-3">Products</h4>
                <div id="product-container">
                    <?php foreach ($order['products'] as $index => $product): ?>
                        <div class="row product-row mb-2">
                            <div class="col-md-5">
                                <select class="form-control product-select" name="product_id[]" required>
                                    <option value="">Select Product</option>
                                    <?php foreach ($products as $p): ?>
                                        <option value="<?= $p['id'] ?>" 
                                            data-price="<?= $p['price'] ?>"
                                            <?= $p['id'] == $product['product_id'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($p['name']) ?> - $<?= number_format($p['price'], 2) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="hidden" name="product_name[]" value="<?= htmlspecialchars($product['product_name']) ?>">
                            </div>
                            <div class="col-md-2">
                                <input type="number" class="form-control" name="product_price[]" 
                                       value="<?= $product['price'] ?>" step="0.01" min="0" required>
                            </div>
                            <div class="col-md-2">
                                <input type="number" class="form-control" name="product_qty[]" 
                                       value="<?= $product['qty'] ?>" min="1" required>
                            </div>
                            <div class="col-md-2">
                                <span class="form-control">$<?= number_format($product['price'] * $product['qty'], 2) ?></span>
                            </div>
                            <div class="col-md-1">
                                <button type="button" class="btn btn-danger remove-product">×</button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <button type="button" id="add-product" class="btn btn-secondary mb-4">Add Product</button>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Update Order</button>
                    <a href="addorder.php" class="btn btn-secondary">Back to Orders</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Add new product row
    document.getElementById('add-product').addEventListener('click', function() {
        const container = document.getElementById('product-container');
        const newRow = container.querySelector('.product-row').cloneNode(true);
        
        // Clear values
        newRow.querySelector('.product-select').selectedIndex = 0;
        newRow.querySelector('[name="product_price[]"]').value = '';
        newRow.querySelector('[name="product_qty[]"]').value = '1';
        newRow.querySelector('.total-price').textContent = '$0.00';
        
        container.appendChild(newRow);
    });
    
    // Remove product row
    document.getElementById('product-container').addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-product')) {
            if (document.querySelectorAll('.product-row').length > 1) {
                e.target.closest('.product-row').remove();
            } else {
                // Clear values but keep the row if it's the last one
                const row = e.target.closest('.product-row');
                row.querySelector('.product-select').selectedIndex = 0;
                row.querySelector('[name="product_price[]"]').value = '';
                row.querySelector('[name="product_qty[]"]').value = '1';
                row.querySelector('.total-price').textContent = '$0.00';
            }
        }
    });
    
    // Update price when product is selected
    document.getElementById('product-container').addEventListener('change', function(e) {
        if (e.target.classList.contains('product-select')) {
            const row = e.target.closest('.product-row');
            const selectedOption = e.target.options[e.target.selectedIndex];
            const priceInput = row.querySelector('[name="product_price[]"]');
            const nameInput = row.querySelector('[name="product_name[]"]');
            
            if (selectedOption.value) {
                priceInput.value = selectedOption.dataset.price;
                nameInput.value = selectedOption.text.split(' - ')[0];
                calculateTotal(row);
            }
        }
    });
    
    // Calculate total when price or quantity changes
    document.getElementById('product-container').addEventListener('input', function(e) {
        if (e.target.name === 'product_price[]' || e.target.name === 'product_qty[]') {
            calculateTotal(e.target.closest('.product-row'));
        }
    });
    
    function calculateTotal(row) {
        const price = parseFloat(row.querySelector('[name="product_price[]"]').value) || 0;
        const qty = parseInt(row.querySelector('[name="product_qty[]"]').value) || 0;
        const total = price * qty;
        row.querySelector('.total-price').textContent = '$' + total.toFixed(2);
    }
    
    // Initialize calculations for existing rows
    document.querySelectorAll('.product-row').forEach(row => {
        calculateTotal(row);
    });
});
</script>

<?php
require('includes/footer.php');
?>