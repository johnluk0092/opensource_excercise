<?php
require_once('includes/header.php');
require('../db/conn.php');

// Initialize variables
$name = $slug = '';
$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $slug = trim($_POST['slug']);
    $status = 'Active'; // Default to Active
    
    // Validate inputs
    if (empty($name)) {
        $error = 'Category name is required';
    } else {
        // Generate slug if empty
        if (empty($slug)) {
            $slug = strtolower(str_replace(' ', '-', $name));
        }
        
        // Check if category exists
        $check = $conn->prepare("SELECT id FROM categories WHERE name = ? OR slug = ?");
        $check->bind_param("ss", $name, $slug);
        $check->execute();
        $check->store_result();
        
        if ($check->num_rows > 0) {
            $error = 'Category already exists!';
        } else {
            // Insert new category (always Active)
            $stmt = $conn->prepare("INSERT INTO categories (name, slug, status, created_at) VALUES (?, ?, 'Active', NOW())");
            $stmt->bind_param("ss", $name, $slug);
            
            if ($stmt->execute()) {
                $success = 'Category added successfully!';
                // Clear form
                $name = $slug = '';
            } else {
                $error = 'Error adding category: ' . $conn->error;
            }
        }
    }
}

// Get only active categories
$categories = [];
$result = $conn->query("SELECT * FROM categories WHERE status = 'Active' ORDER BY created_at DESC");
if ($result && $result->num_rows > 0) {
    $categories = $result->fetch_all(MYSQLI_ASSOC);
}
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <h2 class="mb-4">Add New Category</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label for="name">Category Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($name) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="slug">Slug</label>
                    <input type="text" class="form-control" id="slug" name="slug" value="<?= htmlspecialchars($slug) ?>">
                    <small class="text-muted">Leave blank to auto-generate</small>
                </div>
                
                <button type="submit" class="btn btn-primary">Add Category</button>
            </form>
            
            <hr>
            
            <h3 class="mt-5">Active Categories</h3>
            <?php if (empty($categories)): ?>
                <p>No active categories found.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Slug</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($categories as $category): ?>
                                <tr>
                                    <td><?= $category['id'] ?></td>
                                    <td><?= htmlspecialchars($category['name']) ?></td>
                                    <td><?= htmlspecialchars($category['slug']) ?></td>
                                    <td><?= date('M d, Y', strtotime($category['created_at'])) ?></td>
                                    <td>
                                        <a href="editcategory.php?id=<?= $category['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                                        <a href="deletecategory.php?id=<?= $category['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this category?')">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php
require_once('includes/footer.php');
?>