<?php 
require_once('includes/header.php');
require_once('../db/conn.php');

// Fetch order details with product and order information
$order_details = $conn->query("
    SELECT od.*, p.name as product_name, o.firstname, o.lastname, o.email, o.status as order_status
    FROM order_details od
    JOIN products p ON od.product_id = p.id
    JOIN orders o ON od.order_id = o.id
    ORDER BY od.created_at DESC
    LIMIT 10
")->fetch_all(MYSQLI_ASSOC);

// Function to generate CSV
function generateOrderDetailsCSV($data) {
    $filename = 'order_details_' . date('Y-m-d') . '.csv';
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    
    // Header row
    fputcsv($output, array(
        'Order ID', 
        'Product Name', 
        'Price', 
        'Quantity', 
        'Total', 
        'Customer Name',
        'Customer Email',
        'Order Status',
        'Date'
    ));
    
    // Data rows
    foreach ($data as $row) {
        fputcsv($output, array(
            $row['order_id'],
            $row['product_name'],
            $row['price'],
            $row['qty'],
            $row['total'],
            $row['firstname'] . ' ' . $row['lastname'],
            $row['email'],
            $row['order_status'],
            $row['created_at']
        ));
    }
    
    fclose($output);
    exit();
}

// Handle CSV download
if (isset($_GET['download'])) {
    generateOrderDetailsCSV($order_details);
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
        <a href="download_order_details.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-download fa-sm text-white-50"></i> Download Order Details
        </a>
    </div>

    <!-- Order Details Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Recent Order Details</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Qty</th>
                            <th>Total</th>
                            <th>Customer</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($order_details as $detail): ?>
                        <tr>
                            <td><?= $detail['order_id'] ?></td>
                            <td><?= htmlspecialchars($detail['product_name']) ?></td>
                            <td>$<?= number_format($detail['price'], 2) ?></td>
                            <td><?= $detail['qty'] ?></td>
                            <td>$<?= number_format($detail['total'], 2) ?></td>
                            <td>
                                <?= htmlspecialchars($detail['firstname'] . ' ' . $detail['lastname']) ?><br>
                                <small><?= htmlspecialchars($detail['email']) ?></small>
                            </td>
                            <td>
                                <?php
                                $badge_class = 'secondary';
                                if ($detail['order_status'] == 'Processing') {
                                    $badge_class = 'warning';
                                } elseif ($detail['order_status'] == 'Confirmed') {
                                    $badge_class = 'info';
                                } elseif ($detail['order_status'] == 'Shipping') {
                                    $badge_class = 'primary';
                                } elseif ($detail['order_status'] == 'Delivered') {
                                    $badge_class = 'success';
                                }
                                ?>
                                <span class="badge badge-<?= $badge_class ?>">
                                    <?= $detail['order_status'] ?>
                                </span>
                            </td>
                            <td><?= date('M d, Y', strtotime($detail['created_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Your existing dashboard content here -->
    <!-- ... -->

</div>
<!-- /.container-fluid -->

<?php require_once('includes/footer.php'); ?>