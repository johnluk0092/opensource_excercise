<?php
require('includes/header.php');
require('../db/conn.php');

$id = $_GET['id'] ?? 0;
$error = '';
$success = '';

// Fetch user data
$stmt = $conn->prepare("SELECT id, name, email, phone, address FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    die("User not found");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = [
        'id' => $id,
        'name' => trim($_POST['name']),
        'email' => trim($_POST['email']),
        'phone' => trim($_POST['phone']),
        'address' => trim($_POST['address']),
        'password' => trim($_POST['password']),
        'confirm_password' => trim($_POST['confirm_password'])
    ];
    
    // Validate inputs
    if (empty($user['name']) || empty($user['email']) || empty($user['phone'])) {
        $error = 'Name, email and phone are required';
    } elseif (!filter_var($user['email'], FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format';
    } elseif (!empty($user['password']) && $user['password'] !== $user['confirm_password']) {
        $error = 'Passwords do not match';
    } else {
        // Prepare base update query
        $query = "UPDATE users SET name = ?, email = ?, phone = ?, address = ?";
        $params = [$user['name'], $user['email'], $user['phone'], $user['address']];
        $types = "ssss";
        
        // Add password update if provided
        if (!empty($user['password'])) {
            $hashed_password = password_hash($user['password'], PASSWORD_DEFAULT);
            $query .= ", password = ?";
            $params[] = $hashed_password;
            $types .= "s";
        }
        
        $query .= ", updated_at = NOW() WHERE id = ?";
        $params[] = $user['id'];
        $types .= "i";
        
        $update = $conn->prepare($query);
        $update->bind_param($types, ...$params);
        
        if ($update->execute()) {
            $success = 'User updated successfully!';
            // Refresh user data
            $user = $conn->query("SELECT id, name, email, phone, address FROM users WHERE id = $id")->fetch_assoc();
        } else {
            $error = 'Error updating user: ' . $conn->error;
        }
    }
}
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <h2 class="mb-4">Edit Customer</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" class="form-control" id="name" name="name" 
                           value="<?= htmlspecialchars($user['name']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" 
                           value="<?= htmlspecialchars($user['email']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" class="form-control" id="phone" name="phone" 
                           value="<?= htmlspecialchars($user['phone']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea class="form-control" id="address" name="address"><?= htmlspecialchars($user['address']) ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="password">New Password (leave blank to keep current)</label>
                    <input type="password" class="form-control" id="password" name="password">
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirm New Password</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                </div>
                
                <button type="submit" class="btn btn-primary">Update Customer</button>
                <a href="adduser.php" class="btn btn-secondary">Back to List</a>
            </form>
        </div>
    </div>
</div>
<?php
require('includes/footer.php');
?>