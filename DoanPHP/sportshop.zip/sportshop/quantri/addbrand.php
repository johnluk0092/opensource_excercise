<?php
require('includes/header.php');
require('../db/conn.php');

// Initialize variables
$name = $slug = '';
$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $slug = trim($_POST['slug']);
    
    // Validate inputs
    if (empty($name)) {
        $error = 'Brand name is required';
    } else {
        // Generate slug if empty
        if (empty($slug)) {
            $slug = strtolower(str_replace(' ', '-', $name));
        }
        
        // Check if brand exists
        $check = $conn->prepare("SELECT id FROM brands WHERE name = ? OR slug = ?");
        $check->bind_param("ss", $name, $slug);
        $check->execute();
        $check->store_result();
        
        if ($check->num_rows > 0) {
            $error = 'Brand already exists!';
        } else {
            // Insert new brand (always Active)
            $stmt = $conn->prepare("INSERT INTO brands (name, slug, status, created_at) VALUES (?, ?, 'Active', NOW())");
            $stmt->bind_param("ss", $name, $slug);
            
            if ($stmt->execute()) {
                $success = 'Brand added successfully!';
                // Clear form
                $name = $slug = '';
            } else {
                $error = 'Error adding brand: ' . $conn->error;
            }
        }
    }
}

// Get only active brands
$brands = [];
$result = $conn->query("SELECT * FROM brands WHERE status = 'Active' ORDER BY created_at DESC");
if ($result && $result->num_rows > 0) {
    $brands = $result->fetch_all(MYSQLI_ASSOC);
}
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <h2 class="mb-4">Add New Brand</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label for="name">Brand Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($name) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="slug">Slug</label>
                    <input type="text" class="form-control" id="slug" name="slug" value="<?= htmlspecialchars($slug) ?>">
                    <small class="text-muted">Leave blank to auto-generate</small>
                </div>
                
                <button type="submit" class="btn btn-primary">Add Brand</button>
            </form>
            
            <hr>
            
            <h3 class="mt-5">Active Brands</h3>
            <?php if (empty($brands)): ?>
                <p>No active brands found.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Slug</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($brands as $brand): ?>
                                <tr>
                                    <td><?= $brand['id'] ?></td>
                                    <td><?= htmlspecialchars($brand['name']) ?></td>
                                    <td><?= htmlspecialchars($brand['slug']) ?></td>
                                    <td><?= date('M d, Y', strtotime($brand['created_at'])) ?></td>
                                    <td>
                                        <a href="editbrand.php?id=<?= $brand['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                                        <a href="deletebrand.php?id=<?= $brand['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this brand?')">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php
require('includes/footer.php');
?>