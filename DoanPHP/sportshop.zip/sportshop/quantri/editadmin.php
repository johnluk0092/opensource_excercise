<?php
require('includes/header.php');
require('../db/conn.php');

$id = $_GET['id'] ?? 0;
$error = '';
$success = '';

// Fetch admin data
$stmt = $conn->prepare("SELECT id, name, email, phone, address, type FROM admins WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();

if (!$admin) {
    die("Admin not found");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $type = trim($_POST['type']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    
    // Basic validation
    if (empty($name) || empty($email) || empty($phone)) {
        $error = 'Name, email and phone are required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format';
    } elseif (!empty($password) && $password !== $confirm_password) {
        $error = 'Passwords do not match';
    } else {
        // Prepare base update query
        $query = "UPDATE admins SET name = ?, email = ?, phone = ?, address = ?, type = ?";
        $params = [$name, $email, $phone, $address, $type];
        $types = "sssss";
        
        // Add password update if provided
        if (!empty($password)) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $query .= ", password = ?";
            $params[] = $hashed_password;
            $types .= "s";
        }
        
        $query .= ", updated_at = NOW() WHERE id = ?";
        $params[] = $id;
        $types .= "i";
        
        $update = $conn->prepare($query);
        $update->bind_param($types, ...$params);
        
        if ($update->execute()) {
            $success = 'Admin updated successfully!';
            // Refresh admin data
            $admin = $conn->query("SELECT id, name, email, phone, address, type FROM admins WHERE id = $id")->fetch_assoc();
        } else {
            $error = 'Error updating admin: ' . $conn->error;
        }
    }
}
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <h2 class="mb-4">Edit Admin</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" class="form-control" id="name" name="name" 
                           value="<?= htmlspecialchars($admin['name']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" 
                           value="<?= htmlspecialchars($admin['email']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" class="form-control" id="phone" name="phone" 
                           value="<?= htmlspecialchars($admin['phone']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea class="form-control" id="address" name="address"><?= htmlspecialchars($admin['address']) ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="type">Type</label>
                    <select class="form-control" id="type" name="type" required>
                        <option value="Staff" <?= $admin['type'] == 'Staff' ? 'selected' : '' ?>>Staff</option>
                        <option value="Admin" <?= $admin['type'] == 'Admin' ? 'selected' : '' ?>>Admin</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="password">New Password (leave blank to keep current)</label>
                    <input type="password" class="form-control" id="password" name="password">
                    <small class="text-muted">Minimum 8 characters</small>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirm New Password</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                </div>
                
                <input type="hidden" name="status" value="Active">
                
                <button type="submit" class="btn btn-primary">Update Admin</button>
                <a href="addadmin.php" class="btn btn-secondary">Back to List</a>
            </form>
        </div>
    </div>
</div>
<?php
require('includes/footer.php');
?>