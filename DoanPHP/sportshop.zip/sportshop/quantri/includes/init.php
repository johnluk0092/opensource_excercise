<?php
// This must be the FIRST line with NO whitespace before
ob_start(); // Start output buffering
session_start();

// Your authentication check
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    ob_end_flush();
    exit();
}

// Optional: Check if admin is still active in database
require('../db/conn.php');
$stmt = $conn->prepare("SELECT id FROM admins WHERE id = ? AND status = 'Active'");
$stmt->bind_param("i", $_SESSION['admin_id']);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 0) {
    session_destroy();
    header("Location: login.php");
    ob_end_flush();
    exit();
}
ob_end_clean(); // Clean buffer without sending
?>