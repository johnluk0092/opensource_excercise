<?php
require('include/header.php');
require('include/sidebar.php');
require('db/conn1.php');

// Get search query
$search_query = isset($_GET['search_query']) ? trim($_GET['search_query']) : '';

// Search products
$products = [];
if (!empty($search_query)) {
    $stmt = $conn->prepare("SELECT p.*, c.name as category_name 
                           FROM products p 
                           JOIN categories c ON p.category_id = c.id 
                           WHERE p.status = 'Active' AND p.name LIKE ?");
    $search_param = "%$search_query%";
    $stmt->bind_param("s", $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
}
?>

<!-- Search Results Section -->
<section class="product spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2>Search Results for "<?= htmlspecialchars($search_query) ?>"</h2>
                
                <?php if (!empty($products)): ?>
                    <div class="row">
                        <?php foreach ($products as $product): 
                            $image_path = 'img/' . $product['images'];
                            if (empty($product['images']) || !file_exists($image_path)) {
                                $image_path = 'img/default-product.jpg';
                            }
                        ?>
                            <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="product__item">
                                    <div class="product__item__pic set-bg" data-setbg="<?= htmlspecialchars($image_path) ?>">
                                        <ul class="product__item__pic__hover">
                                            <li><a href="quick_checkout.php?product_id=<?= $product['id'] ?>"><i class="fa fa-shopping-cart"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="product__item__text">
                                        <h6><a href="product-details.php?id=<?= $product['id'] ?>"><?= htmlspecialchars($product['name']) ?></a></h6>
                                        <h5>
                                            <?php if ($product['discounted_price'] > 0): ?>
                                                <?= number_format($product['discounted_price'], 0, ',', '.') ?>₫
                                                <span style="text-decoration: line-through; font-size: 14px; color: #b2b2b2;">
                                                    <?= number_format($product['price'], 0, ',', '.') ?>₫
                                                </span>
                                            <?php else: ?>
                                                <?= number_format($product['price'], 0, ',', '.') ?>₫
                                            <?php endif; ?>
                                        </h5>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning">No products found matching your search.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php
require('include/footer.php');
require('include/script.php');
?>