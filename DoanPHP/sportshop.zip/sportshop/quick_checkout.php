<?php
/* 
 * FIXED ONE-FILE CHECKOUT 
 * Without payment_method column
 */

// ======== DATABASE CONNECTION ========
require('db/conn1.php');

// ======== PROCESS ORDER ========
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);
    
    try {
        // 1. Get product price
        $stmt = $conn->prepare("SELECT price FROM products WHERE id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        $total = $product['price'] * $quantity;
        
        // 2. Create order (without payment_method)
        $stmt = $conn->prepare("INSERT INTO orders 
            (status, firstname, lastname, address, phone, email) 
            VALUES ('Processing', ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss",
            $_POST['firstname'],
            $_POST['lastname'],
            $_POST['address'],
            $_POST['phone'],
            $_POST['email']
        );
        $stmt->execute();
        $order_id = $conn->insert_id;
        
        // 3. Add to order_details
        $stmt = $conn->prepare("INSERT INTO order_details 
            (order_id, product_id, qty, price, total)
            VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iiidd", $order_id, $product_id, $quantity, $product['price'], $total);
        $stmt->execute();
        
        // Show success
        header("Location: quick_checkout.php?success=1&order_id=$order_id");
        exit;
        
    } catch (Exception $e) {
        die("Error: " . $e->getMessage());
    }
}

// ======== SHOW CHECKOUT FORM ========
if (isset($_GET['product_id'])) {
    $product_id = intval($_GET['product_id']);
    $product = $conn->query("SELECT * FROM products WHERE id = $product_id")->fetch_assoc();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Complete Checkout</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body { font-family: Arial; max-width: 600px; margin: 0 auto; padding: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select, button { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; }
        button { background: #4CAF50; color: white; border: none; cursor: pointer; margin-top: 20px; font-size: 16px; }
        .success { color: green; text-align: center; margin: 20px 0; }
        .total-price { font-size: 20px; color: #E91E63; font-weight: bold; margin: 15px 0; }
        .section-title { border-bottom: 1px solid #eee; padding-bottom: 5px; margin-top: 20px; }
    </style>
</head>
<body>

    <?php if (isset($_GET['success'])): ?>
        <div class="success">
            <h2><i class="fas fa-check-circle"></i> Order #<?= $_GET['order_id'] ?> Completed!</h2>
            <p>Status: Processing</p>
            <a href="products.php">Back to Products</a>
        </div>

    <?php elseif (isset($product)): ?>
        <h1>Checkout: <?= htmlspecialchars($product['name']) ?></h1>
        <p>Unit Price: <?= number_format($product['price'], 0, ',', '.') ?>₫</p>
        
        <form method="POST">
            <input type="hidden" name="product_id" value="<?= $product_id ?>">
            
            <div class="form-group">
                <label>Quantity:</label>
                <select name="quantity" id="quantity" onchange="updateTotal(<?= $product['price'] ?>)">
                    <?php for($i=1; $i<=10; $i++): ?>
                        <option value="<?= $i ?>"><?= $i ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            
            <div class="total-price" id="totalPrice">
                Total: <?= number_format($product['price'], 0, ',', '.') ?>₫
            </div>
            
            <h3 class="section-title">Customer Information</h3>
            <div class="form-group">
                <label>First Name</label>
                <input type="text" name="firstname" required value=" ">
            </div>
            
            <div class="form-group">
                <label>Last Name</label>
                <input type="text" name="lastname" required value=" ">
            </div>
            
            <div class="form-group">
                <label>Address</label>
                <input type="text" name="address" required value=" ">
            </div>
            
            <div class="form-group">
                <label>Phone</label>
                <input type="text" name="phone" required value=" ">
            </div>
            
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" required value=" ">
            </div>
            
            <h3 class="section-title">Payment Information</h3>
            <div class="form-group">
                <label>Card Number</label>
                <input type="text" name="card_number" placeholder="Enter card number">
            </div>

            <div class="form-group">
                <label>Expiry Date</label>
                <input type="text" name="expiry_date" placeholder="MM/YY">
            </div>

            <div class="form-group">
                <label>CVV</label>
                <input type="text" name="cvv" placeholder="123">
            </div>
            
            <button type="submit">
                <i class="fas fa-check"></i> COMPLETE ORDER
            </button>
        </form>
        
        <script>
        function updateTotal(price) {
            const qty = document.getElementById('quantity').value;
            const total = (price * qty).toLocaleString();
            document.getElementById('totalPrice').innerText = `Total: ${total}₫`;
        }
        </script>

    <?php else: ?>
        <p>No product selected. <a href="products.php">Go back</a></p>
    <?php endif; ?>

</body>
</html>